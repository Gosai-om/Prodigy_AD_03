package com.example.stop_watch

import android.os.Bundle
import android.os.Handler
import android.os.SystemClock
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat


class MainActivity : AppCompatActivity() {

    private lateinit var displayTextView: TextView
    private lateinit var startButton: Button
    private lateinit var pauseButton: Button
    private lateinit var resetButton: Button

    private var startTime = 0L  // Stores start time in milliseconds
    private var elapsedTime = 0L  // Stores elapsed time in milliseconds
    private var isRunning = false  // Flag to track running state

    private val handler = Handler()  // Create a Handler instance

    private val runnable = object : Runnable {
        override fun run() {
            if (isRunning) {
                elapsedTime = SystemClock.elapsedRealtime() - startTime
                updateDisplay()
            }
            // Schedule the next update with a delay of 1 millisecond
            handler.postAtTime(this, SystemClock.uptimeMillis() + 1)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        displayTextView = findViewById(R.id.display)
        startButton = findViewById(R.id.startButton)
        pauseButton = findViewById(R.id.pauseButton)
        resetButton = findViewById(R.id.resetButton)

        startButton.setOnClickListener {
            startTimer()
        }

        pauseButton.setOnClickListener {
            pauseTimer()
        }

        resetButton.setOnClickListener {
            resetTimer()
        }
    }

    private fun startTimer() {
        if (isRunning) return  // Prevent multiple starts
        isRunning = true
        startTime = SystemClock.elapsedRealtime() - elapsedTime  // Get current time minus elapsed time
        updateDisplay()  // Update display initially
        startButton.isEnabled = false
        pauseButton.isEnabled = true
        handler.postAtTime(runnable, SystemClock.uptimeMillis() + 1)  // Schedule the first update
    }

    private fun pauseTimer() {
        if (!isRunning) return  // Prevent multiple pauses
        isRunning = false
        elapsedTime = SystemClock.elapsedRealtime() - startTime  // Calculate elapsed time
        handler.removeCallbacks(runnable)  // Stop scheduled updates
        updateDisplay()
        startButton.isEnabled = true
        pauseButton.isEnabled = false
    }

    private fun resetTimer() {
        isRunning = false
        handler.removeCallbacks(runnable)  // Stop scheduled updates
        elapsedTime = 0L  // Reset elapsed time
        updateDisplay()
        startButton.isEnabled = true
        pauseButton.isEnabled = false
    }

    private fun updateDisplay() {
        val seconds = (elapsedTime / 1000) % 60
        val minutes = (elapsedTime / (1000 * 60)) % 60
        val milliseconds = (elapsedTime % 1000)
        val formattedTime = String.format("%02d:%02d:%03d", minutes, seconds, milliseconds)
        displayTextView.text = formattedTime
    }
}